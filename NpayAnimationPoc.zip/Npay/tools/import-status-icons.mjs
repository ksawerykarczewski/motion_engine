#!/usr/bin/env node
import { readFileSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const repoRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const assetRoot = join(repoRoot, "app/src/main/assets/status-icons");
const svgRoot = join(assetRoot, "svg");
const catalogPath = join(assetRoot, "catalog.json");
const outputPath = join(
  repoRoot,
  "app/src/main/java/com/npay/animationpoc/ui/statusicons/StatusIconAsset.kt",
);

const catalog = JSON.parse(readFileSync(catalogPath, "utf8"));

const colorFallback = "#000000";
const validationWarnings = [];

const icons = catalog.icons.map((entry) => {
  const svg = readFileSync(join(svgRoot, entry.svg), "utf8");
  validateCatalogEntry(entry, svg);
  const viewBox = parseViewBox(svg);
  const defaultColor = normalizePaint(entry.defaultColor) ?? colorFallback;
  const vectorPaths = parsePathTags(svg).map((path) => toVectorPath(path, defaultColor));
  validateParsedIcon(entry, vectorPaths);
  const inferredTracePaths = vectorPaths
    .filter((path) => path.stroke && !path.fill)
    .map((path) => ({
      pathData: path.pathData,
      stroke: path.stroke,
      strokeWidth: path.strokeWidth || 1,
    }));
  const tracePaths = (entry.tracePaths?.length ? entry.tracePaths : inferredTracePaths)
    .map((tracePath) => ({
      pathData: tracePath.pathData,
      stroke: tracePath.stroke,
      strokeWidth: Number(tracePath.strokeWidth ?? 1),
    }));

  return {
    enumName: entry.enumName,
    label: entry.label,
    description: entry.description,
    sourceSvg: entry.svg,
    viewportWidth: viewBox.width,
    viewportHeight: viewBox.height,
    vectorPaths,
    tracePaths,
  };
});

validationWarnings.forEach((warning) => console.warn(`Warning: ${warning}`));
writeFileSync(outputPath, renderKotlin(icons));
console.log(`Generated ${outputPath}`);

function validateCatalogEntry(entry, svg) {
  const label = entry.enumName ?? entry.svg ?? "Unknown";
  if (!entry.enumName || !/^[A-Z][A-Za-z0-9]*$/.test(entry.enumName)) {
    throw new Error(`${label}: enumName must be a PascalCase Kotlin enum identifier.`);
  }
  if (!entry.label) {
    throw new Error(`${label}: label is required.`);
  }
  if (!entry.description) {
    validationWarnings.push(`${label}: description is missing; handoff context will be weak.`);
  }
  if (!entry.svg) {
    throw new Error(`${label}: svg filename is required.`);
  }
  if (!entry.defaultColor) {
    validationWarnings.push(`${label}: defaultColor is missing; generated paths may fall back to black.`);
  }
  if (/<(?:mask|clipPath|linearGradient|radialGradient|filter)\b/i.test(svg)) {
    validationWarnings.push(`${label}: SVG contains masks, clipping, gradients, or filters. The importer only preserves simple paths.`);
  }
  if (/\btransform\s*=/i.test(svg)) {
    validationWarnings.push(`${label}: SVG contains transforms. Flatten transforms in Figma before handoff.`);
  }
  if (/<style\b|\bclass\s*=/i.test(svg)) {
    validationWarnings.push(`${label}: SVG contains styles/classes. Inline path attributes before handoff.`);
  }
  if (/\b(?:opacity|fill-opacity|stroke-opacity)\s*=/i.test(svg)) {
    validationWarnings.push(`${label}: SVG contains opacity attributes. Verify generated Compose output visually.`);
  }
}

function validateParsedIcon(entry, vectorPaths) {
  const label = entry.enumName;
  if (vectorPaths.length === 0) {
    throw new Error(`${label}: SVG must contain at least one path.`);
  }
  if (entry.enumName === "Loading" && vectorPaths.length < 2) {
    validationWarnings.push(`${label}: loading presets need multiple paths for sequential animation.`);
  }
  if (
    entry.enumName !== "Loading" &&
    !entry.tracePaths?.length &&
    vectorPaths.every((path) => path.fill && !path.stroke)
  ) {
    validationWarnings.push(`${label}: filled-only SVG has no tracePaths; path reveal will fall back to final vector rendering.`);
  }
  entry.tracePaths?.forEach((tracePath, index) => {
    if (!tracePath.pathData || !tracePath.stroke || !tracePath.strokeWidth) {
      throw new Error(`${label}: tracePaths[${index}] needs pathData, stroke, and strokeWidth.`);
    }
  });
}

function parseViewBox(svg) {
  const viewBox = svg.match(/viewBox\s*=\s*"([^"]+)"/i)?.[1];
  if (!viewBox) {
    throw new Error("SVG is missing a viewBox.");
  }

  const [, , width, height] = viewBox
    .trim()
    .split(/[\s,]+/)
    .map((value) => Number(value));

  if (!Number.isFinite(width) || !Number.isFinite(height)) {
    throw new Error(`Invalid viewBox: ${viewBox}`);
  }

  return { width, height };
}

function parsePathTags(svg) {
  return [...svg.matchAll(/<path\b([^>]*)\/?>/gi)].map((match) => {
    const attributes = Object.fromEntries(
      [...match[1].matchAll(/([:\w-]+)\s*=\s*"([^"]*)"/g)].map(([, key, value]) => [
        key,
        value,
      ]),
    );
    if (!attributes.d) {
      throw new Error(`Path is missing d attribute: ${match[0]}`);
    }
    return attributes;
  });
}

function toVectorPath(attributes, defaultColor) {
  const fill = normalizePaint(attributes.fill, defaultColor);
  const stroke = normalizePaint(attributes.stroke, defaultColor);

  return {
    pathData: attributes.d,
    fill: fill === "none" ? null : fill ?? (stroke ? null : colorFallback),
    stroke: stroke === "none" ? null : stroke,
    strokeWidth: Number(attributes["stroke-width"] ?? 0),
    strokeCap: toStrokeCap(attributes["stroke-linecap"]),
    strokeJoin: toStrokeJoin(attributes["stroke-linejoin"]),
  };
}

function normalizePaint(value, defaultColor = null) {
  if (!value) return null;
  if (value === "currentColor") return defaultColor;
  if (value.toLowerCase() === "none") return "none";
  if (/^#[0-9a-f]{3}$/i.test(value)) {
    return `#${value[1]}${value[1]}${value[2]}${value[2]}${value[3]}${value[3]}`;
  }
  if (/^#[0-9a-f]{6}$/i.test(value)) return value.toUpperCase();
  throw new Error(`Unsupported color value: ${value}`);
}

function toStrokeCap(value) {
  switch (value) {
    case "butt":
      return "Butt";
    case "square":
      return "Square";
    default:
      return "Round";
  }
}

function toStrokeJoin(value) {
  switch (value) {
    case "bevel":
      return "Bevel";
    case "miter":
      return "Miter";
    default:
      return "Round";
  }
}

function renderKotlin(iconEntries) {
  return `package com.npay.animationpoc.ui.statusicons

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin

data class StatusIconVectorPath(
    val pathData: String,
    val fill: Color? = null,
    val stroke: Color? = null,
    val strokeWidth: Float = 0f,
    val strokeCap: StrokeCap = StrokeCap.Round,
    val strokeJoin: StrokeJoin = StrokeJoin.Round,
)

data class StatusIconTracePath(
    val pathData: String,
    val stroke: Color,
    val strokeWidth: Float,
)

enum class StatusIconAsset(
    val label: String,
    val description: String,
    val sourceSvg: String,
    val viewportWidth: Float,
    val viewportHeight: Float,
    val vectorPaths: List<StatusIconVectorPath>,
    val tracePaths: List<StatusIconTracePath> = emptyList(),
) {
${iconEntries.map(renderIcon).join(",\n")};
}
`;
}

function renderIcon(icon) {
  const tracePaths = icon.tracePaths.length
    ? `,
        tracePaths = listOf(
${icon.tracePaths.map(renderTracePath).join(",\n")}
        )`
    : "";

  return `    ${icon.enumName}(
        label = ${kotlinString(icon.label)},
        description = ${kotlinString(icon.description)},
        sourceSvg = ${kotlinString(icon.sourceSvg)},
        viewportWidth = ${kotlinFloat(icon.viewportWidth)},
        viewportHeight = ${kotlinFloat(icon.viewportHeight)},
        vectorPaths = listOf(
${icon.vectorPaths.map(renderVectorPath).join(",\n")}
        )${tracePaths},
    )`;
}

function renderVectorPath(path) {
  return `            StatusIconVectorPath(
                pathData = ${kotlinString(path.pathData)},
                fill = ${path.fill ? kotlinColor(path.fill) : "null"},
                stroke = ${path.stroke ? kotlinColor(path.stroke) : "null"},
                strokeWidth = ${kotlinFloat(path.strokeWidth)},
                strokeCap = StrokeCap.${path.strokeCap},
                strokeJoin = StrokeJoin.${path.strokeJoin},
            )`;
}

function renderTracePath(path) {
  return `            StatusIconTracePath(
                pathData = ${kotlinString(path.pathData)},
                stroke = ${kotlinColor(path.stroke)},
                strokeWidth = ${kotlinFloat(path.strokeWidth)},
            )`;
}

function kotlinColor(hex) {
  return `Color(0xFF${hex.replace("#", "").toUpperCase()})`;
}

function kotlinFloat(value) {
  const normalized = Number(value);
  return `${Number.isInteger(normalized) ? normalized.toFixed(1) : normalized}f`;
}

function kotlinString(value) {
  return `"${String(value).replaceAll("\\", "\\\\").replaceAll('"', '\\"')}"`;
}
