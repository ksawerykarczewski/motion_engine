# Keep project-specific rules here as animation experiments grow.
