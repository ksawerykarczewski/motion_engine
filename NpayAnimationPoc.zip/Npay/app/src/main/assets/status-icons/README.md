# Status icon source assets

Place source SVG files for status states in `svg/`.

For maximum animation control, the app does not render SVG files directly at runtime. Each icon is registered in `StatusIconAsset.kt` with viewport metadata, final vector paths, optional centerline trace paths, labels, descriptions, and colors. That keeps the animation layer in Jetpack Compose, where path reveal, timing, easing, alpha, scale, loop behavior, and future per-path choreography can be controlled directly.

## Replacing an icon

For the common case, do this:

1. Replace the SVG file in `app/src/main/assets/status-icons/svg/`.
2. If the file name, label, description, or fallback color changed, update `catalog.json`.
3. Run:

```bash
node tools/import-status-icons.mjs
```

The importer reads the SVG `viewBox`, path data, fill, stroke, stroke width, line caps, and line joins, then regenerates `StatusIconAsset.kt`.

It also validates common Figma handoff problems and prints warnings for transforms, masks/clips/gradients/filters, styles/classes, opacity attributes, missing descriptions, and loading SVGs with too few paths.

For stroke-based SVGs, trace paths are inferred automatically. For filled SVGs, path reveal cannot be inferred reliably; use static, fade, pop, or pulse, or add explicit centerline `tracePaths` in `catalog.json`.

## Manual details

The generated Kotlin contains one `StatusIconVectorPath` per SVG path. For fluid path animation, add centerline `StatusIconTracePath` entries in `catalog.json`. Avoid tracing filled outline paths; `PathMeasure` should measure the visual motion path, not the filled shape boundary.

If an SVG has multiple paths, add each path as a separate `StatusIconVectorPath`. For path reveal, add `StatusIconTracePath` entries in the order they should draw. The renderer length-weights trace paths so long paths naturally receive more animation time.

Loading does not need explicit `tracePaths` for the built-in sequential styles. `SequentialAppear` and `SequentialAlphaPulse` animate the generated `StatusIconVectorPath` list directly, so sequence order follows SVG path order. `SequentialAppear` uses one vector layer and moves a single hidden gap through the path list while every other segment stays fully visible. Reorder paths in the SVG when the loading rhythm should change.
