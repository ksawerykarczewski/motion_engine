package com.npay.animationpoc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.npay.animationpoc.ui.PaymentAnimationComparisonApp
import com.npay.animationpoc.ui.theme.NpayAnimationPocTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NpayAnimationPocTheme {
                PaymentAnimationComparisonApp()
            }
        }
    }
}
