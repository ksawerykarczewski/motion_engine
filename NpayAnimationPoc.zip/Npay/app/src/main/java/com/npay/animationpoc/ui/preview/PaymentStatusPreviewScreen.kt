package com.npay.animationpoc.ui.preview

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.npay.animationpoc.ui.motionspec.PaymentMotionSpec
import com.npay.animationpoc.ui.motionspec.ValidationSeverity
import com.npay.animationpoc.ui.statusanimation.AnimatedStatusIcon
import com.npay.animationpoc.ui.statusanimation.StatusAnimationStyle
import com.npay.animationpoc.ui.statusanimation.StatusEasingPreset
import com.npay.animationpoc.ui.statusanimation.StatusIconAnimationPresets
import com.npay.animationpoc.ui.statusanimation.StatusIconAnimationSpec
import com.npay.animationpoc.ui.statusanimation.StatusLoopMode
import com.npay.animationpoc.ui.statusanimation.isLoadingSequentialStyle
import com.npay.animationpoc.ui.statusicons.StatusIconAsset
import com.npay.animationpoc.ui.theme.NpayAnimationPocTheme
import kotlin.math.roundToInt

private enum class WorkspaceView(val label: String) {
    Design("Design"),
    Handoff("Handoff"),
}

@Composable
fun PaymentStatusPreviewScreen() {
    var selectedIcon by remember { mutableStateOf(StatusIconAsset.Success) }
    var animationSpec by remember {
        mutableStateOf(StatusIconAnimationPresets.recommendedFor(selectedIcon))
    }
    var replayKey by remember { mutableIntStateOf(0) }
    var reducedMotion by remember { mutableStateOf(false) }
    var selectedView by remember { mutableStateOf(WorkspaceView.Design) }
    var approvedSpecs by remember { mutableStateOf<Map<StatusIconAsset, PaymentMotionSpec>>(emptyMap()) }
    val draftMotionSpec = PaymentMotionSpec.from(
        icon = selectedIcon,
        animationSpec = animationSpec,
    )
    val handoffMotionSpec = approvedSpecs[selectedIcon] ?: draftMotionSpec

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        containerColor = MaterialTheme.colorScheme.background,
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            PreviewHeader(
                reducedMotion = reducedMotion,
                onReducedMotionChange = {
                    reducedMotion = it
                    replayKey++
                },
            )
            SegmentedControl(
                label = "Workspace",
                entries = WorkspaceView.entries.toList(),
                selected = selectedView,
                itemLabel = { it.label },
                onSelected = { selectedView = it },
            )
            when (selectedView) {
                WorkspaceView.Design -> {
                    PreviewPanel(
                        icon = selectedIcon,
                        animationSpec = animationSpec,
                        replayKey = replayKey,
                        reducedMotion = reducedMotion,
                        onReplay = { replayKey++ },
                    )
                    PreviewControls(
                        selectedIcon = selectedIcon,
                        onIconChange = { icon ->
                            selectedIcon = icon
                            animationSpec = approvedSpecs[icon]?.toAnimationSpec()
                                ?: StatusIconAnimationPresets.recommendedFor(icon)
                            replayKey++
                        },
                        animationSpec = animationSpec,
                        onAnimationSpecChange = { spec ->
                            animationSpec = spec
                            replayKey++
                        },
                    )
                    HandoffActionCard(
                        onMarkForHandoff = {
                            approvedSpecs = approvedSpecs + (selectedIcon to draftMotionSpec)
                            selectedView = WorkspaceView.Handoff
                        },
                    )
                }
                WorkspaceView.Handoff -> {
                    HandoffPanel(
                        icon = selectedIcon,
                        motionSpec = handoffMotionSpec,
                        isApproved = approvedSpecs.containsKey(selectedIcon),
                        replayKey = replayKey,
                        reducedMotion = reducedMotion,
                        onReplay = { replayKey++ },
                    )
                }
            }
        }
    }
}

@Composable
private fun PreviewHeader(
    reducedMotion: Boolean,
    onReducedMotionChange: (Boolean) -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "Payment status motion",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
                text = "Native Compose preview for SVG-derived status icons.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Card(
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Reduced motion",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        text = "Show the final state without animated progress.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = reducedMotion, onCheckedChange = onReducedMotionChange)
            }
        }
    }
}

@Composable
private fun PreviewPanel(
    icon: StatusIconAsset,
    animationSpec: StatusIconAnimationSpec,
    replayKey: Int,
    reducedMotion: Boolean,
    onReplay: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = icon.label,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        text = icon.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                OutlinedButton(onClick = onReplay) {
                    Text("Replay")
                }
            }
            Spacer(modifier = Modifier.height(18.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp),
                contentAlignment = Alignment.Center,
            ) {
                AnimatedStatusIcon(
                    icon = icon,
                    animationSpec = animationSpec,
                    replayKey = replayKey,
                    reducedMotion = reducedMotion,
                    modifier = Modifier.size(132.dp),
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PreviewControls(
    selectedIcon: StatusIconAsset,
    onIconChange: (StatusIconAsset) -> Unit,
    animationSpec: StatusIconAnimationSpec,
    onAnimationSpecChange: (StatusIconAnimationSpec) -> Unit,
) {
    val isSequentialStyle = animationSpec.style.isLoadingSequentialStyle()
    val usesGapTransition = animationSpec.style == StatusAnimationStyle.SequentialAppear

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            PaymentStateSegmentedControl(
                label = "Payment state",
                entries = StatusIconAsset.entries.toList(),
                selected = selectedIcon,
                onSelected = onIconChange,
            )
            SegmentedControl(
                label = "Animation style",
                entries = animationStylesFor(selectedIcon),
                selected = animationSpec.style,
                itemLabel = { it.label },
                onSelected = { style ->
                    onAnimationSpecChange(StatusIconAnimationPresets.forStyle(style, selectedIcon))
                },
            )
            SegmentedControl(
                label = if (usesGapTransition) "Transition easing" else "Easing",
                entries = easingPresetsFor(animationSpec.style),
                selected = if (usesGapTransition) {
                    animationSpec.transitionEasingPreset
                } else {
                    animationSpec.easingPreset
                },
                itemLabel = { it.label },
                onSelected = { easing ->
                    if (usesGapTransition) {
                        onAnimationSpecChange(animationSpec.copy(transitionEasingPreset = easing))
                    } else {
                        onAnimationSpecChange(animationSpec.copy(easingPreset = easing))
                    }
                },
            )
            SliderControl(
                label = "Duration",
                valueLabel = "${animationSpec.durationMillis} ms",
                value = animationSpec.durationMillis.toFloat(),
                valueRange = if (isSequentialStyle) 400f..2000f else 0f..1500f,
                steps = if (isSequentialStyle) 31 else 29,
                onValueChange = { value ->
                    onAnimationSpecChange(animationSpec.copy(durationMillis = value.roundToNearest(50)))
                },
            )
            if (usesGapTransition) {
                SliderControl(
                    label = "Transition duration",
                    valueLabel = "${animationSpec.transitionDurationMillis} ms",
                    value = animationSpec.transitionDurationMillis.toFloat(),
                    valueRange = 30f..240f,
                    steps = 20,
                    onValueChange = { value ->
                        onAnimationSpecChange(
                            animationSpec.copy(transitionDurationMillis = value.roundToNearest(10)),
                        )
                    },
                )
            }
            if (!isSequentialStyle) {
                SliderControl(
                    label = "Delay",
                    valueLabel = "${animationSpec.delayMillis} ms",
                    value = animationSpec.delayMillis.toFloat(),
                    valueRange = 0f..500f,
                    steps = 9,
                    onValueChange = { value ->
                        onAnimationSpecChange(animationSpec.copy(delayMillis = value.roundToNearest(50)))
                    },
                )
                SliderControl(
                    label = "Scale",
                    valueLabel = "${animationSpec.startScale.formatScale()} -> ${animationSpec.endScale.formatScale()}",
                    value = animationSpec.endScale,
                    valueRange = 0.8f..1.2f,
                    steps = 7,
                    onValueChange = { value ->
                        onAnimationSpecChange(animationSpec.copy(endScale = value.roundToNearestStep(0.05f)))
                    },
                )
                SliderControl(
                    label = "Alpha",
                    valueLabel = "${animationSpec.startAlpha.formatScale()} -> ${animationSpec.endAlpha.formatScale()}",
                    value = animationSpec.startAlpha,
                    valueRange = 0f..1f,
                    steps = 9,
                    onValueChange = { value ->
                        onAnimationSpecChange(animationSpec.copy(startAlpha = value.roundToNearestStep(0.1f)))
                    },
                )
                ToggleRow(
                    label = "Path reveal",
                    checked = animationSpec.pathReveal,
                    onCheckedChange = { enabled ->
                        onAnimationSpecChange(animationSpec.copy(pathReveal = enabled))
                    },
                )
                ToggleRow(
                    label = "Loop",
                    checked = animationSpec.loop,
                    onCheckedChange = { loop ->
                        onAnimationSpecChange(animationSpec.copy(loop = loop))
                    },
                )
                if (animationSpec.loop) {
                    SegmentedControl(
                        label = "Loop mode",
                        entries = StatusLoopMode.entries.toList(),
                        selected = animationSpec.loopMode,
                        itemLabel = { it.label },
                        onSelected = { loopMode ->
                            onAnimationSpecChange(animationSpec.copy(loopMode = loopMode))
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun HandoffActionCard(
    onMarkForHandoff: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    text = "Ready for handoff",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                )
                Text(
                    text = "Save the current motion spec and review generated output.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Button(onClick = onMarkForHandoff) {
                Text("Mark")
            }
        }
    }
}

@Composable
private fun HandoffPanel(
    icon: StatusIconAsset,
    motionSpec: PaymentMotionSpec,
    isApproved: Boolean,
    replayKey: Int,
    reducedMotion: Boolean,
    onReplay: () -> Unit,
) {
    val validationMessages = motionSpec.validate(icon)

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        PreviewPanel(
            icon = icon,
            animationSpec = motionSpec.toAnimationSpec(),
            replayKey = replayKey,
            reducedMotion = reducedMotion,
            onReplay = onReplay,
        )
        HandoffSummaryCard(
            icon = icon,
            motionSpec = motionSpec,
            isApproved = isApproved,
        )
        ValidationCard(messages = validationMessages)
        ExportTextCard(
            title = "motion-spec.json",
            body = motionSpec.toJson(),
        )
        ExportTextCard(
            title = "Compose handoff",
            body = motionSpec.toComposeSnippet(),
        )
        ExportTextCard(
            title = "Implementation reference",
            body = motionSpec.toImplementationReference(),
        )
    }
}

@Composable
private fun HandoffSummaryCard(
    icon: StatusIconAsset,
    motionSpec: PaymentMotionSpec,
    isApproved: Boolean,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text = if (isApproved) "Approved handoff spec" else "Draft handoff spec",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            SpecRow(label = "State", value = motionSpec.state)
            SpecRow(label = "Asset", value = motionSpec.assetFile)
            SpecRow(label = "Preset", value = motionSpec.preset.wireName)
            SpecRow(label = "Duration", value = "${motionSpec.durationMillis} ms")
            SpecRow(label = "Loop", value = motionSpec.loop.toString())
            SpecRow(label = "Vector paths", value = icon.vectorPaths.size.toString())
            SpecRow(label = "Trace paths", value = icon.tracePaths.size.toString())
        }
    }
}

@Composable
private fun ValidationCard(messages: List<com.npay.animationpoc.ui.motionspec.MotionValidationMessage>) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = "Validation",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            messages.forEach { message ->
                Text(
                    text = "${message.severity.label()}: ${message.message}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun ExportTextCard(
    title: String,
    body: String,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            SelectionContainer {
                Text(
                    text = body,
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun SpecRow(
    label: String,
    value: String,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun <T> SegmentedControl(
    label: String,
    entries: List<T>,
    selected: T,
    itemLabel: (T) -> String,
    onSelected: (T) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
        )
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            entries.forEachIndexed { index, entry ->
                SegmentedButton(
                    selected = entry == selected,
                    onClick = { onSelected(entry) },
                    shape = SegmentedButtonDefaults.itemShape(index = index, count = entries.size),
                ) {
                    Text(itemLabel(entry))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PaymentStateSegmentedControl(
    label: String,
    entries: List<StatusIconAsset>,
    selected: StatusIconAsset,
    onSelected: (StatusIconAsset) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
        )
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            entries.forEachIndexed { index, entry ->
                SegmentedButton(
                    selected = entry == selected,
                    onClick = { onSelected(entry) },
                    shape = SegmentedButtonDefaults.itemShape(index = index, count = entries.size),
                ) {
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        AnimatedStatusIcon(
                            icon = entry,
                            animationSpec = StatusIconAnimationSpec(
                                style = StatusAnimationStyle.Static,
                                durationMillis = 0,
                                pathReveal = false,
                            ),
                            replayKey = 0,
                            reducedMotion = true,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.size(6.dp))
                        Text(entry.label)
                    }
                }
            }
        }
    }
}

@Composable
private fun SliderControl(
    label: String,
    valueLabel: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    steps: Int,
    onValueChange: (Float) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                text = valueLabel,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            steps = steps,
        )
    }
}

@Composable
private fun ToggleRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
        )
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

private fun Float.roundToNearest(step: Int): Int {
    return (this / step).roundToInt() * step
}

private fun Float.roundToNearestStep(step: Float): Float {
    return (this / step).roundToInt() * step
}

private fun Float.formatScale(): String {
    return "%.2f".format(this)
}

private fun animationStylesFor(icon: StatusIconAsset): List<StatusAnimationStyle> {
    return if (icon == StatusIconAsset.Loading) {
        listOf(
            StatusAnimationStyle.SequentialAppear,
            StatusAnimationStyle.SequentialAlphaPulse,
        )
    } else {
        StatusAnimationStyle.entries.filterNot { it.isLoadingSequentialStyle() }
    }
}

private fun easingPresetsFor(style: StatusAnimationStyle): List<StatusEasingPreset> {
    return if (style == StatusAnimationStyle.SequentialAppear) {
        StatusEasingPreset.entries.toList()
    } else if (style.isLoadingSequentialStyle()) {
        listOf(StatusEasingPreset.Linear)
    } else {
        StatusEasingPreset.entries.toList()
    }
}

private fun ValidationSeverity.label(): String {
    return when (this) {
        ValidationSeverity.Info -> "Info"
        ValidationSeverity.Warning -> "Warning"
        ValidationSeverity.Error -> "Error"
    }
}

@Preview(showBackground = true)
@Composable
private fun PaymentStatusPreviewScreenPreview() {
    NpayAnimationPocTheme {
        PaymentStatusPreviewScreen()
    }
}
