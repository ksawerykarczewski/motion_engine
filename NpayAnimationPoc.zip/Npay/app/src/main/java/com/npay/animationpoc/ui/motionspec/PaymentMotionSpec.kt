package com.npay.animationpoc.ui.motionspec

import com.npay.animationpoc.ui.statusanimation.StatusAnimationStyle
import com.npay.animationpoc.ui.statusanimation.StatusEasingPreset
import com.npay.animationpoc.ui.statusanimation.StatusIconAnimationSpec
import com.npay.animationpoc.ui.statusanimation.StatusLoopMode
import com.npay.animationpoc.ui.statusicons.StatusIconAsset

enum class MotionPreset(val wireName: String) {
    Static("static"),
    Trace("trace"),
    Fade("fade"),
    Pop("pop"),
    Pulse("pulse"),
    SequentialAppear("sequentialAppear"),
    SequentialPulse("sequentialPulse"),
}

enum class MotionEasing(val wireName: String) {
    Pos("pos"),
    Emphasized("emphasized"),
    Linear("linear"),
}

enum class MotionLoopMode(val wireName: String) {
    Cycle("cycle"),
    Yoyo("yoyo"),
}

enum class ReducedMotionMode(val wireName: String) {
    Static("static"),
}

enum class ValidationSeverity {
    Info,
    Warning,
    Error,
}

data class MotionTransitionSpec(
    val durationMillis: Int,
    val easing: MotionEasing,
)

data class ReducedMotionSpec(
    val mode: ReducedMotionMode = ReducedMotionMode.Static,
)

data class MotionValidationMessage(
    val severity: ValidationSeverity,
    val message: String,
)

data class PaymentMotionSpec(
    val state: String,
    val assetId: String,
    val assetFile: String,
    val preset: MotionPreset,
    val durationMillis: Int,
    val delayMillis: Int,
    val easing: MotionEasing,
    val loop: Boolean,
    val loopMode: MotionLoopMode,
    val pathReveal: Boolean,
    val startAlpha: Float,
    val endAlpha: Float,
    val startScale: Float,
    val endScale: Float,
    val transition: MotionTransitionSpec?,
    val reducedMotion: ReducedMotionSpec = ReducedMotionSpec(),
) {
    fun toAnimationSpec(): StatusIconAnimationSpec {
        return StatusIconAnimationSpec(
            style = preset.toStatusAnimationStyle(),
            durationMillis = durationMillis,
            delayMillis = delayMillis,
            easingPreset = easing.toStatusEasingPreset(),
            loop = loop,
            loopMode = loopMode.toStatusLoopMode(),
            pathReveal = pathReveal,
            startAlpha = startAlpha,
            endAlpha = endAlpha,
            startScale = startScale,
            endScale = endScale,
            transitionDurationMillis = transition?.durationMillis ?: 90,
            transitionEasingPreset = transition?.easing?.toStatusEasingPreset() ?: StatusEasingPreset.Pos,
        )
    }

    fun validate(icon: StatusIconAsset): List<MotionValidationMessage> {
        val messages = mutableListOf<MotionValidationMessage>()

        if (durationMillis < 0) {
            messages += MotionValidationMessage(ValidationSeverity.Error, "Duration must be zero or greater.")
        }
        if (durationMillis > 2000) {
            messages += MotionValidationMessage(ValidationSeverity.Warning, "Duration is high for POS feedback; verify on device.")
        }
        if (delayMillis > 500) {
            messages += MotionValidationMessage(ValidationSeverity.Warning, "Delay above 500 ms may make payment feedback feel slow.")
        }
        if (preset == MotionPreset.Trace && icon.tracePaths.isEmpty()) {
            messages += MotionValidationMessage(
                ValidationSeverity.Error,
                "Trace preset needs explicit centerline trace paths for this asset.",
            )
        }
        if ((preset == MotionPreset.SequentialAppear || preset == MotionPreset.SequentialPulse) && icon.vectorPaths.size < 2) {
            messages += MotionValidationMessage(
                ValidationSeverity.Error,
                "Sequential loading presets need at least two SVG paths.",
            )
        }
        if (preset == MotionPreset.SequentialAppear && transition == null) {
            messages += MotionValidationMessage(
                ValidationSeverity.Warning,
                "Sequential appear should include a transition spec for the moving gap handoff.",
            )
        }
        transition?.let { transition ->
            if (transition.durationMillis !in 30..240) {
                messages += MotionValidationMessage(
                    ValidationSeverity.Warning,
                    "Transition duration should usually stay between 30 ms and 240 ms.",
                )
            }
        }
        if (loop && preset !in setOf(MotionPreset.Pulse, MotionPreset.SequentialAppear, MotionPreset.SequentialPulse)) {
            messages += MotionValidationMessage(
                ValidationSeverity.Warning,
                "Looping is usually reserved for processing/loading states.",
            )
        }
        if (preset == MotionPreset.SequentialPulse) {
            messages += MotionValidationMessage(
                ValidationSeverity.Info,
                "Sequential pulse intentionally uses alpha internally; keep this for loading only.",
            )
        }
        if (messages.none { it.severity == ValidationSeverity.Error || it.severity == ValidationSeverity.Warning }) {
            messages += MotionValidationMessage(ValidationSeverity.Info, "Spec is ready for developer handoff.")
        }

        return messages
    }

    fun toJson(): String {
        val properties = mutableListOf<String>()

        properties += "\"state\": ${state.jsonString()}"
        properties += "\"assetId\": ${assetId.jsonString()}"
        properties += "\"assetFile\": ${assetFile.jsonString()}"
        properties += "\"preset\": ${preset.wireName.jsonString()}"
        properties += "\"durationMs\": $durationMillis"

        if (delayMillis > 0) {
            properties += "\"delayMs\": $delayMillis"
        }
        if (preset.usesGlobalEasing()) {
            properties += "\"easing\": ${easing.wireName.jsonString()}"
        }
        if (loop || preset.isLoopPreset()) {
            properties += "\"loop\": $loop"
        }
        if (loop) {
            properties += "\"loopMode\": ${loopMode.wireName.jsonString()}"
        }
        if (pathReveal || preset == MotionPreset.Trace) {
            properties += "\"pathReveal\": $pathReveal"
        }
        if (preset.usesExportedAlpha(this)) {
            properties += "\"alpha\": { \"from\": ${startAlpha.formatJsonFloat()}, \"to\": ${endAlpha.formatJsonFloat()} }"
        }
        if (preset.usesExportedScale(this)) {
            properties += "\"scale\": { \"from\": ${startScale.formatJsonFloat()}, \"to\": ${endScale.formatJsonFloat()} }"
        }
        transition?.let {
            properties += """
            "transition": {
              "durationMs": ${it.durationMillis},
              "easing": ${it.easing.wireName.jsonString()}
            }
            """.trimIndent()
        }
        properties += """
        "reducedMotion": {
          "mode": ${reducedMotion.mode.wireName.jsonString()}
        }
        """.trimIndent()

        return properties.joinToString(
            separator = ",\n",
            prefix = "{\n",
            postfix = "\n}",
        ) { property ->
            property.prependIndent("  ")
        }
    }

    fun toComposeSnippet(): String {
        return """
        PaymentStatusIcon(
            state = PaymentStatusState.${state},
            motion = PaymentStatusMotion.${preset.toKotlinName()},
            modifier = Modifier.size(64.dp),
        )
        """.trimIndent()
    }

    fun toImplementationReference(): String {
        return buildString {
            appendLine("// Developer implementation reference for ${preset.toKotlinName()}")
            appendLine("// ${preset.description()}")
            appendLine()
            appendLine("import androidx.compose.animation.core.CubicBezierEasing")
            appendLine("import androidx.compose.animation.core.LinearEasing")
            appendLine("import androidx.compose.animation.core.tween")
            appendLine()
            appendLine(easing.toComposeEasingDeclaration("motionEasing"))
            transition?.let { transition ->
                appendLine(transition.easing.toComposeEasingDeclaration("transitionEasing"))
            }
            appendLine()
            appendLine("val ${preset.toKotlinName()} = PaymentMotionSpec(")
            appendLine("    preset = ${preset.toKotlinName().quoted()},")
            appendLine("    durationMillis = $durationMillis,")
            appendLine("    delayMillis = $delayMillis,")
            appendLine("    easing = motionEasing,")
            appendLine("    loop = $loop,")
            appendLine("    loopMode = ${loopMode.wireName.quoted()},")
            appendLine("    pathReveal = $pathReveal,")
            appendLine("    startAlpha = ${startAlpha.formatKotlinFloat()},")
            appendLine("    endAlpha = ${endAlpha.formatKotlinFloat()},")
            appendLine("    startScale = ${startScale.formatKotlinFloat()},")
            appendLine("    endScale = ${endScale.formatKotlinFloat()},")
            transition?.let { transition ->
                appendLine("    transitionDurationMillis = ${transition.durationMillis},")
                appendLine("    transitionEasing = transitionEasing,")
            }
            appendLine(")")
            appendLine()
            appendLine("val motionTween = tween<Float>(")
            appendLine("    durationMillis = $durationMillis,")
            appendLine("    delayMillis = $delayMillis,")
            appendLine("    easing = motionEasing,")
            appendLine(")")
            appendLine()
            appendLine(preset.rendererNotes(this@PaymentMotionSpec))
        }
    }

    companion object {
        fun from(
            icon: StatusIconAsset,
            animationSpec: StatusIconAnimationSpec,
        ): PaymentMotionSpec {
            return PaymentMotionSpec(
                state = icon.name,
                assetId = icon.name.replaceFirstChar { it.lowercase() },
                assetFile = icon.sourceSvg,
                preset = animationSpec.style.toMotionPreset(),
                durationMillis = animationSpec.durationMillis,
                delayMillis = animationSpec.delayMillis,
                easing = animationSpec.easingPreset.toMotionEasing(),
                loop = animationSpec.loop,
                loopMode = animationSpec.loopMode.toMotionLoopMode(),
                pathReveal = animationSpec.pathReveal,
                startAlpha = animationSpec.startAlpha,
                endAlpha = animationSpec.endAlpha,
                startScale = animationSpec.startScale,
                endScale = animationSpec.endScale,
                transition = if (animationSpec.style == StatusAnimationStyle.SequentialAppear) {
                    MotionTransitionSpec(
                        durationMillis = animationSpec.transitionDurationMillis,
                        easing = animationSpec.transitionEasingPreset.toMotionEasing(),
                    )
                } else {
                    null
                },
            )
        }
    }
}

private fun StatusAnimationStyle.toMotionPreset(): MotionPreset {
    return when (this) {
        StatusAnimationStyle.Static -> MotionPreset.Static
        StatusAnimationStyle.Trace -> MotionPreset.Trace
        StatusAnimationStyle.Fade -> MotionPreset.Fade
        StatusAnimationStyle.Pop -> MotionPreset.Pop
        StatusAnimationStyle.Pulse -> MotionPreset.Pulse
        StatusAnimationStyle.SequentialAppear -> MotionPreset.SequentialAppear
        StatusAnimationStyle.SequentialAlphaPulse -> MotionPreset.SequentialPulse
    }
}

private fun MotionPreset.toStatusAnimationStyle(): StatusAnimationStyle {
    return when (this) {
        MotionPreset.Static -> StatusAnimationStyle.Static
        MotionPreset.Trace -> StatusAnimationStyle.Trace
        MotionPreset.Fade -> StatusAnimationStyle.Fade
        MotionPreset.Pop -> StatusAnimationStyle.Pop
        MotionPreset.Pulse -> StatusAnimationStyle.Pulse
        MotionPreset.SequentialAppear -> StatusAnimationStyle.SequentialAppear
        MotionPreset.SequentialPulse -> StatusAnimationStyle.SequentialAlphaPulse
    }
}

private fun StatusEasingPreset.toMotionEasing(): MotionEasing {
    return when (this) {
        StatusEasingPreset.Pos -> MotionEasing.Pos
        StatusEasingPreset.Emphasized -> MotionEasing.Emphasized
        StatusEasingPreset.Linear -> MotionEasing.Linear
    }
}

private fun MotionEasing.toStatusEasingPreset(): StatusEasingPreset {
    return when (this) {
        MotionEasing.Pos -> StatusEasingPreset.Pos
        MotionEasing.Emphasized -> StatusEasingPreset.Emphasized
        MotionEasing.Linear -> StatusEasingPreset.Linear
    }
}

private fun StatusLoopMode.toMotionLoopMode(): MotionLoopMode {
    return when (this) {
        StatusLoopMode.Cycle -> MotionLoopMode.Cycle
        StatusLoopMode.Yoyo -> MotionLoopMode.Yoyo
    }
}

private fun MotionLoopMode.toStatusLoopMode(): StatusLoopMode {
    return when (this) {
        MotionLoopMode.Cycle -> StatusLoopMode.Cycle
        MotionLoopMode.Yoyo -> StatusLoopMode.Yoyo
    }
}

private fun MotionPreset.toKotlinName(): String {
    return when (this) {
        MotionPreset.Static -> "Static"
        MotionPreset.Trace -> "Trace"
        MotionPreset.Fade -> "Fade"
        MotionPreset.Pop -> "Pop"
        MotionPreset.Pulse -> "Pulse"
        MotionPreset.SequentialAppear -> "SequentialAppear"
        MotionPreset.SequentialPulse -> "SequentialPulse"
    }
}

private fun MotionPreset.description(): String {
    return when (this) {
        MotionPreset.Static -> "Render final vector state without animated progress."
        MotionPreset.Trace -> "Reveal explicit centerline trace paths with PathMeasure.getSegment(), then use the final vector at rest."
        MotionPreset.Fade -> "Fade the final vector from startAlpha to endAlpha, with optional restrained scale."
        MotionPreset.Pop -> "Fade in while scaling from startScale to endScale using emphasized easing."
        MotionPreset.Pulse -> "Loop the final vector between startScale and endScale; use yoyo repeat for calm emphasis."
        MotionPreset.SequentialAppear -> "For multi-path loading icons, render one vector path list and move a single hidden gap through SVG path order."
        MotionPreset.SequentialPulse -> "For multi-path loading icons, keep all paths visible and move a subtle alpha emphasis through SVG path order."
    }
}

private fun MotionPreset.usesGlobalEasing(): Boolean {
    return when (this) {
        MotionPreset.Trace,
        MotionPreset.Fade,
        MotionPreset.Pop,
        MotionPreset.Pulse -> true
        MotionPreset.Static,
        MotionPreset.SequentialAppear,
        MotionPreset.SequentialPulse -> false
    }
}

private fun MotionPreset.isLoopPreset(): Boolean {
    return when (this) {
        MotionPreset.Pulse,
        MotionPreset.SequentialAppear,
        MotionPreset.SequentialPulse -> true
        MotionPreset.Static,
        MotionPreset.Trace,
        MotionPreset.Fade,
        MotionPreset.Pop -> false
    }
}

private fun MotionPreset.usesExportedAlpha(spec: PaymentMotionSpec): Boolean {
    return when (this) {
        MotionPreset.Trace,
        MotionPreset.Fade,
        MotionPreset.Pop,
        MotionPreset.Pulse -> spec.startAlpha != 1f || spec.endAlpha != 1f
        MotionPreset.Static,
        MotionPreset.SequentialAppear,
        MotionPreset.SequentialPulse -> false
    }
}

private fun MotionPreset.usesExportedScale(spec: PaymentMotionSpec): Boolean {
    return when (this) {
        MotionPreset.Trace,
        MotionPreset.Fade,
        MotionPreset.Pop,
        MotionPreset.Pulse -> spec.startScale != 1f || spec.endScale != 1f
        MotionPreset.Static,
        MotionPreset.SequentialAppear,
        MotionPreset.SequentialPulse -> false
    }
}

private fun MotionPreset.rendererNotes(spec: PaymentMotionSpec): String {
    return when (this) {
        MotionPreset.Static -> """
        // Renderer behavior:
        // - Do not start Animatable.
        // - Draw the final ImageVector immediately.
        """.trimIndent()
        MotionPreset.Trace -> """
        // Renderer behavior:
        // - Build Path objects from explicit trace paths.
        // - Measure each path with PathMeasure.
        // - Draw PathMeasure.getSegment(0f, length * localProgress, destination, true).
        // - Use length-weighted timing when an icon has multiple trace paths.
        """.trimIndent()
        MotionPreset.Fade -> """
        // Renderer behavior:
        // - progress = Animatable(0f).animateTo(1f, motionTween)
        // - alpha = lerp(${spec.startAlpha.formatKotlinFloat()}, ${spec.endAlpha.formatKotlinFloat()}, progress)
        // - scale = lerp(${spec.startScale.formatKotlinFloat()}, ${spec.endScale.formatKotlinFloat()}, progress)
        // - Draw one final ImageVector instance.
        """.trimIndent()
        MotionPreset.Pop -> """
        // Renderer behavior:
        // - progress = Animatable(0f).animateTo(1f, motionTween)
        // - alpha = lerp(${spec.startAlpha.formatKotlinFloat()}, ${spec.endAlpha.formatKotlinFloat()}, progress)
        // - scale = lerp(${spec.startScale.formatKotlinFloat()}, ${spec.endScale.formatKotlinFloat()}, progress)
        // - Draw one final ImageVector instance with graphicsLayer alpha/scale.
        """.trimIndent()
        MotionPreset.Pulse -> """
        // Renderer behavior:
        // - Loop Animatable between 0f and 1f.
        // - If loopMode == "yoyo", animate forward then backward.
        // - scale = lerp(${spec.startScale.formatKotlinFloat()}, ${spec.endScale.formatKotlinFloat()}, progress)
        // - Draw one final ImageVector instance.
        """.trimIndent()
        MotionPreset.SequentialAppear -> """
        // Renderer behavior:
        // - Use LinearEasing for the overall loop timeline.
        // - Render exactly one vector path list. Do not draw a base/background vector.
        // - currentGapIndex = floor(loopProgress * pathCount).
        // - During the local transition window, ease the current hidden path back in and the next path out.
        // - transitionDurationMillis = ${spec.transition?.durationMillis ?: 90}
        // - transitionEasing = ${spec.transition?.easing?.wireName ?: MotionEasing.Pos.wireName}
        """.trimIndent()
        MotionPreset.SequentialPulse -> """
        // Renderer behavior:
        // - Use LinearEasing for the overall loop timeline.
        // - Render exactly one vector path list.
        // - Keep all paths visible.
        // - Move alpha emphasis through SVG path order with one path emphasized at a time.
        // - Keep this preset for loading/processing states only.
        """.trimIndent()
    }
}

private fun MotionEasing.toComposeEasingDeclaration(name: String): String {
    return when (this) {
        MotionEasing.Pos -> "val $name = CubicBezierEasing(0.2f, 0f, 0f, 1f)"
        MotionEasing.Emphasized -> "val $name = CubicBezierEasing(0.16f, 1f, 0.3f, 1f)"
        MotionEasing.Linear -> "val $name = LinearEasing"
    }
}

private fun String.quoted(): String {
    return "\"$this\""
}

private fun Float.formatKotlinFloat(): String {
    return "%.2ff".format(this)
}

private fun String.jsonString(): String {
    return "\"${replace("\\", "\\\\").replace("\"", "\\\"")}\""
}

private fun Float.formatJsonFloat(): String {
    return "%.2f".format(this)
}
