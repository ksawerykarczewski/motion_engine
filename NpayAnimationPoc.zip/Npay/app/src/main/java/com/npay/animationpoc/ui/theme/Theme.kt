package com.npay.animationpoc.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF2933C8),
    onPrimary = Color.White,
    secondary = Color(0xFF006B4F),
    background = Color(0xFFF7F7FA),
    onBackground = Color(0xFF191A20),
    surface = Color.White,
    onSurface = Color(0xFF191A20),
    surfaceVariant = Color(0xFFEDEEF5),
    onSurfaceVariant = Color(0xFF5F6270),
    outline = Color(0xFF858897),
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFBDC2FF),
    onPrimary = Color(0xFF10156D),
    secondary = Color(0xFF7DDCBF),
    background = Color(0xFF111216),
    onBackground = Color(0xFFE7E8EF),
    surface = Color(0xFF1A1B21),
    onSurface = Color(0xFFE7E8EF),
    surfaceVariant = Color(0xFF262832),
    onSurfaceVariant = Color(0xFFC7C8D2),
    outline = Color(0xFF8E909C),
)

@Composable
fun NpayAnimationPocTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme: ColorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content,
    )
}
