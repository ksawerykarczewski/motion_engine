package com.npay.animationpoc.ui.statusanimation

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.LinearEasing
import com.npay.animationpoc.ui.statusicons.StatusIconAsset

enum class StatusAnimationStyle(val label: String) {
    Static("Static"),
    Trace("Trace"),
    Fade("Fade"),
    Pop("Pop"),
    Pulse("Pulse"),
    SequentialAppear("Sequential appear"),
    SequentialAlphaPulse("Sequential pulse"),
}

fun StatusAnimationStyle.isLoadingSequentialStyle(): Boolean {
    return when (this) {
        StatusAnimationStyle.SequentialAppear,
        StatusAnimationStyle.SequentialAlphaPulse -> true
        else -> false
    }
}

enum class StatusLoopMode(val label: String) {
    Cycle("Cycle"),
    Yoyo("Yoyo"),
}

enum class StatusEasingPreset(
    val label: String,
    val easing: Easing,
) {
    Pos("POS", CubicBezierEasing(0.2f, 0f, 0f, 1f)),
    Emphasized("Emphasis", CubicBezierEasing(0.16f, 1f, 0.3f, 1f)),
    Linear("Linear", LinearEasing),
}

data class StatusIconAnimationSpec(
    val style: StatusAnimationStyle,
    val durationMillis: Int,
    val delayMillis: Int = 0,
    val easingPreset: StatusEasingPreset = StatusEasingPreset.Pos,
    val loop: Boolean = false,
    val loopMode: StatusLoopMode = StatusLoopMode.Cycle,
    val pathReveal: Boolean = true,
    val startAlpha: Float = 1f,
    val endAlpha: Float = 1f,
    val startScale: Float = 1f,
    val endScale: Float = 1f,
    val transitionDurationMillis: Int = 90,
    val transitionEasingPreset: StatusEasingPreset = StatusEasingPreset.Pos,
)

object StatusIconAnimationPresets {
    fun recommendedFor(icon: StatusIconAsset): StatusIconAnimationSpec {
        return when (icon) {
            StatusIconAsset.Success -> StatusIconAnimationSpec(
                style = StatusAnimationStyle.Trace,
                durationMillis = 420,
                delayMillis = 40,
                easingPreset = StatusEasingPreset.Pos,
                pathReveal = true,
            )
            StatusIconAsset.Error -> StatusIconAnimationSpec(
                style = StatusAnimationStyle.Pop,
                durationMillis = 220,
                easingPreset = StatusEasingPreset.Emphasized,
                pathReveal = false,
                startAlpha = 0f,
                startScale = 0.92f,
            )
            StatusIconAsset.Failure,
            StatusIconAsset.Decline -> StatusIconAnimationSpec(
                style = StatusAnimationStyle.Fade,
                durationMillis = 180,
                easingPreset = StatusEasingPreset.Pos,
                pathReveal = false,
                startAlpha = 0f,
                startScale = 0.98f,
            )
            StatusIconAsset.Loading -> StatusIconAnimationSpec(
                style = StatusAnimationStyle.SequentialAlphaPulse,
                durationMillis = 1200,
                easingPreset = StatusEasingPreset.Linear,
                loop = true,
                pathReveal = false,
                startAlpha = 0.35f,
                endAlpha = 1f,
                startScale = 1f,
                endScale = 1f,
            )
        }
    }

    fun forStyle(style: StatusAnimationStyle, icon: StatusIconAsset): StatusIconAnimationSpec {
        return when (style) {
            StatusAnimationStyle.Static -> StatusIconAnimationSpec(
                style = style,
                durationMillis = 0,
                pathReveal = false,
            )
            StatusAnimationStyle.Trace -> StatusIconAnimationSpec(
                style = style,
                durationMillis = if (icon == StatusIconAsset.Success) 420 else 320,
                delayMillis = 40,
                easingPreset = StatusEasingPreset.Pos,
                pathReveal = true,
            )
            StatusAnimationStyle.Fade -> StatusIconAnimationSpec(
                style = style,
                durationMillis = 180,
                easingPreset = StatusEasingPreset.Pos,
                pathReveal = false,
                startAlpha = 0f,
            )
            StatusAnimationStyle.Pop -> StatusIconAnimationSpec(
                style = style,
                durationMillis = 220,
                easingPreset = StatusEasingPreset.Emphasized,
                pathReveal = false,
                startAlpha = 0f,
                startScale = 0.9f,
            )
            StatusAnimationStyle.Pulse -> StatusIconAnimationSpec(
                style = style,
                durationMillis = 700,
                easingPreset = StatusEasingPreset.Pos,
                loop = true,
                loopMode = StatusLoopMode.Yoyo,
                pathReveal = false,
                startScale = 0.94f,
                endScale = 1.04f,
            )
            StatusAnimationStyle.SequentialAppear -> sequentialAppear(style)
            StatusAnimationStyle.SequentialAlphaPulse -> StatusIconAnimationSpec(
                style = style,
                durationMillis = 1200,
                easingPreset = StatusEasingPreset.Linear,
                loop = true,
                pathReveal = false,
                startAlpha = 0.35f,
                endAlpha = 1f,
            )
        }
    }

    private fun sequentialAppear(style: StatusAnimationStyle): StatusIconAnimationSpec {
        return StatusIconAnimationSpec(
            style = style,
            durationMillis = 1000,
            easingPreset = StatusEasingPreset.Linear,
            loop = true,
            pathReveal = false,
            startAlpha = 0.28f,
            endAlpha = 1f,
            transitionDurationMillis = 90,
            transitionEasingPreset = StatusEasingPreset.Pos,
        )
    }
}
