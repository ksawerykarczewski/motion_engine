package com.npay.animationpoc.ui.theme

import androidx.compose.material3.Typography

val Typography = Typography()
