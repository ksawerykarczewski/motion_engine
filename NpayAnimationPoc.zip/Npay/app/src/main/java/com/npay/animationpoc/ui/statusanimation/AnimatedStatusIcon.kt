package com.npay.animationpoc.ui.statusanimation

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.unit.dp
import com.npay.animationpoc.ui.statusicons.StatusIconAsset
import com.npay.animationpoc.ui.statusicons.StatusIconVectorPath
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.math.abs
import kotlin.math.floor

private const val MinimumYoyoTraceProgress = 0.12f
private const val SequentialFullAlpha = 1f
private const val SequentialPulseRestingAlpha = 0.32f

@Composable
fun AnimatedStatusIcon(
    icon: StatusIconAsset,
    animationSpec: StatusIconAnimationSpec,
    replayKey: Int,
    reducedMotion: Boolean,
    modifier: Modifier = Modifier,
) {
    val progress = remember { Animatable(1f) }

    LaunchedEffect(replayKey, reducedMotion, icon, animationSpec) {
        if (reducedMotion || animationSpec.style == StatusAnimationStyle.Static) {
            progress.snapTo(1f)
            return@LaunchedEffect
        }

        if (animationSpec.loop) {
            val loopStartProgress = animationSpec.loopStartProgress()
            while (isActive) {
                progress.snapTo(loopStartProgress)
                if (animationSpec.delayMillis > 0) {
                    delay(animationSpec.delayMillis.toLong())
                }
                progress.animateTo(
                    targetValue = 1f,
                    animationSpec = animationSpec.asTween(),
                )
                if (animationSpec.loopMode == StatusLoopMode.Yoyo) {
                    progress.animateTo(
                        targetValue = loopStartProgress,
                        animationSpec = animationSpec.asTween(),
                    )
                }
            }
        } else {
            progress.snapTo(0f)
            if (animationSpec.delayMillis > 0) {
                delay(animationSpec.delayMillis.toLong())
            }
            progress.animateTo(
                targetValue = 1f,
                animationSpec = animationSpec.asTween(),
            )
        }
    }

    val fraction = progress.value
    val alpha = lerp(animationSpec.startAlpha, animationSpec.endAlpha, fraction)
    val scale = lerp(animationSpec.startScale, animationSpec.endScale, fraction)
    val iconVector = remember(icon) { icon.toImageVector() }
    val vectorPaths = remember(icon) { icon.toParsedVectorPaths() }
    val measuredTracePaths = remember(icon) { icon.toMeasuredTracePaths() }
    val shouldTracePath = animationSpec.pathReveal && measuredTracePaths.isNotEmpty()

    if (animationSpec.style.isLoadingSequentialStyle() && vectorPaths.size > 1 && !reducedMotion) {
        SequentialVectorStatusIcon(
            icon = icon,
            paths = vectorPaths,
            progress = fraction,
            animationSpec = animationSpec,
            modifier = modifier,
        )
    } else if (shouldTracePath) {
        TraceStatusIcon(
            icon = icon,
            paths = measuredTracePaths,
            progress = fraction,
            alpha = alpha,
            scale = scale,
            modifier = modifier,
        )
    } else {
        Image(
            painter = rememberVectorPainter(image = iconVector),
            contentDescription = icon.label,
            modifier = modifier.graphicsLayer {
                this.alpha = alpha
                scaleX = scale
                scaleY = scale
            },
        )
    }
}

@Composable
private fun SequentialVectorStatusIcon(
    icon: StatusIconAsset,
    paths: List<ParsedVectorPath>,
    progress: Float,
    animationSpec: StatusIconAnimationSpec,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier = modifier) {
        val iconScale = minOf(
            size.width / icon.viewportWidth,
            size.height / icon.viewportHeight,
        )
        val translation = Offset(
            x = (size.width - (icon.viewportWidth * iconScale)) / 2f,
            y = (size.height - (icon.viewportHeight * iconScale)) / 2f,
        )

        translate(left = translation.x, top = translation.y) {
            scale(scale = iconScale, pivot = Offset.Zero) {
                paths.forEachIndexed { index, path ->
                    drawParsedVectorPath(
                        path = path,
                        alpha = sequentialPathAlpha(
                            index = index,
                            pathCount = paths.size,
                            progress = progress,
                            animationSpec = animationSpec,
                        ),
                    )
                }
            }
        }
    }
}

@Composable
private fun TraceStatusIcon(
    icon: StatusIconAsset,
    paths: List<MeasuredTracePath>,
    progress: Float,
    alpha: Float,
    scale: Float,
    modifier: Modifier = Modifier,
) {
    Canvas(
        modifier = modifier.graphicsLayer {
            this.alpha = alpha
            scaleX = scale
            scaleY = scale
        },
    ) {
        val iconScale = minOf(
            size.width / icon.viewportWidth,
            size.height / icon.viewportHeight,
        )
        val translation = Offset(
            x = (size.width - (icon.viewportWidth * iconScale)) / 2f,
            y = (size.height - (icon.viewportHeight * iconScale)) / 2f,
        )

        translate(left = translation.x, top = translation.y) {
            scale(scale = iconScale, pivot = Offset.Zero) {
                paths.forEach { tracePath ->
                    drawPath(
                        path = tracePath.path.segment(tracePath.segmentProgress(progress)),
                        color = tracePath.stroke,
                        style = Stroke(
                            width = tracePath.strokeWidth,
                            cap = tracePath.strokeCap,
                            join = tracePath.strokeJoin,
                        ),
                    )
                }
            }
        }
    }
}

private fun StatusIconAnimationSpec.asTween() = tween<Float>(
    durationMillis = durationMillis.coerceAtLeast(1),
    easing = if (style.isLoadingSequentialStyle()) LinearEasing else easingPreset.easing,
)

private fun StatusIconAnimationSpec.loopStartProgress(): Float {
    return if (loopMode == StatusLoopMode.Yoyo && pathReveal) {
        MinimumYoyoTraceProgress
    } else {
        0f
    }
}

private fun StatusIconAsset.toImageVector(): ImageVector {
    return ImageVector.Builder(
        defaultWidth = viewportWidth.dp,
        defaultHeight = viewportHeight.dp,
        viewportWidth = viewportWidth,
        viewportHeight = viewportHeight,
    ).apply {
        vectorPaths.forEach { path ->
            addPath(
                pathData = PathParser().parsePathString(path.pathData).toNodes(),
                fill = path.fill?.let(::SolidColor),
                stroke = path.stroke?.let(::SolidColor),
                strokeLineWidth = path.strokeWidth,
                strokeLineCap = path.strokeCap,
                strokeLineJoin = path.strokeJoin,
            )
        }
    }.build()
}

private fun StatusIconAsset.toParsedVectorPaths(): List<ParsedVectorPath> {
    return vectorPaths.map { path ->
        path.toParsedVectorPath()
    }
}

private fun StatusIconVectorPath.toParsedVectorPath(): ParsedVectorPath {
    return ParsedVectorPath(
        path = PathParser().parsePathString(pathData).toPath(),
        fill = fill,
        stroke = stroke,
        strokeWidth = strokeWidth,
        strokeCap = strokeCap,
        strokeJoin = strokeJoin,
    )
}

private fun StatusIconAsset.toMeasuredTracePaths(): List<MeasuredTracePath> {
    val parsedPaths = tracePaths.map { tracePath ->
        val path = PathParser().parsePathString(tracePath.pathData).toPath()
        val length = path.length()
        ParsedTracePath(
            path = path,
            stroke = tracePath.stroke,
            strokeWidth = tracePath.strokeWidth,
            length = length,
        )
    }
    val totalLength = parsedPaths.sumOf { it.length.toDouble() }.toFloat().coerceAtLeast(1f)
    var consumedLength = 0f

    return parsedPaths.map { tracePath ->
        val start = consumedLength / totalLength
        consumedLength += tracePath.length
        MeasuredTracePath(
            path = tracePath.path,
            stroke = tracePath.stroke,
            strokeWidth = tracePath.strokeWidth,
            strokeCap = androidx.compose.ui.graphics.StrokeCap.Round,
            strokeJoin = androidx.compose.ui.graphics.StrokeJoin.Round,
            startProgress = start,
            endProgress = consumedLength / totalLength,
        )
    }
}

private fun DrawScope.drawParsedVectorPath(
    path: ParsedVectorPath,
    alpha: Float,
) {
    val clampedAlpha = alpha.coerceIn(0f, 1f)
    if (clampedAlpha <= 0f) return

    path.fill?.let { fill ->
        drawPath(
            path = path.path,
            color = fill,
            alpha = clampedAlpha,
        )
    }
    path.stroke?.let { stroke ->
        drawPath(
            path = path.path,
            color = stroke,
            alpha = clampedAlpha,
            style = Stroke(
                width = path.strokeWidth,
                cap = path.strokeCap,
                join = path.strokeJoin,
            ),
        )
    }
}

private fun sequentialPathAlpha(
    index: Int,
    pathCount: Int,
    progress: Float,
    animationSpec: StatusIconAnimationSpec,
): Float {
    val loopProgress = progress.loopProgress()
    return when (animationSpec.style) {
        StatusAnimationStyle.SequentialAppear -> sequentialAppearAlpha(
            index = index,
            pathCount = pathCount,
            progress = loopProgress,
            animationSpec = animationSpec,
        )
        StatusAnimationStyle.SequentialAlphaPulse -> sequentialPulseAlpha(
            index = index,
            pathCount = pathCount,
            progress = loopProgress,
        )
        else -> animationSpec.endAlpha
    }
}

private fun sequentialAppearAlpha(
    index: Int,
    pathCount: Int,
    progress: Float,
    animationSpec: StatusIconAnimationSpec,
): Float {
    val stepPosition = progress * pathCount
    val currentGapIndex = floor(stepPosition).toInt().coerceIn(0, pathCount - 1)
    val nextGapIndex = (currentGapIndex + 1) % pathCount
    val localProgress = stepPosition - floor(stepPosition)
    val transitionFraction = animationSpec.gapTransitionFraction(pathCount)
    val transitionStart = 1f - transitionFraction

    if (localProgress < transitionStart) {
        return if (index == currentGapIndex) 0f else SequentialFullAlpha
    }

    val transitionProgress = ((localProgress - transitionStart) / transitionFraction).coerceIn(0f, 1f)
    val easedProgress = animationSpec.transitionEasingPreset.easing.transform(transitionProgress)

    return when (index) {
        currentGapIndex -> easedProgress
        nextGapIndex -> 1f - easedProgress
        else -> SequentialFullAlpha
    }
}

private fun StatusIconAnimationSpec.gapTransitionFraction(pathCount: Int): Float {
    val stepDurationMillis = durationMillis.toFloat() / pathCount.coerceAtLeast(1)
    if (stepDurationMillis <= 0f) return 0.01f
    return (transitionDurationMillis / stepDurationMillis).coerceIn(0.05f, 0.85f)
}

private fun sequentialPulseAlpha(
    index: Int,
    pathCount: Int,
    progress: Float,
): Float {
    val position = progress * pathCount
    val distance = circularDistance(
        index = index.toFloat(),
        position = position,
        pathCount = pathCount.toFloat(),
    )
    val emphasis = (1f - distance).coerceIn(0f, 1f)
    return lerp(SequentialPulseRestingAlpha, SequentialFullAlpha, emphasis)
}

private fun circularDistance(
    index: Float,
    position: Float,
    pathCount: Float,
): Float {
    val directDistance = abs(index - position)
    return minOf(directDistance, pathCount - directDistance)
}

private fun Float.loopProgress(): Float {
    return if (this >= 1f) {
        0.9999f
    } else {
        coerceIn(0f, 1f)
    }
}

private fun Path.length(): Float {
    val measure = PathMeasure()
    measure.setPath(this, false)
    return measure.length
}

private fun Path.segment(progress: Float): Path {
    val destination = Path()
    if (progress <= 0f) return destination

    val measure = PathMeasure()
    measure.setPath(this, false)
    measure.getSegment(
        startDistance = 0f,
        stopDistance = measure.length * progress.coerceIn(0f, 1f),
        destination = destination,
        startWithMoveTo = true,
    )
    return destination
}

private fun MeasuredTracePath.segmentProgress(progress: Float): Float {
    return ((progress - startProgress) / (endProgress - startProgress)).coerceIn(0f, 1f)
}

private fun lerp(start: Float, stop: Float, fraction: Float): Float {
    return start + ((stop - start) * fraction)
}

private data class ParsedTracePath(
    val path: Path,
    val stroke: Color,
    val strokeWidth: Float,
    val length: Float,
)

private data class ParsedVectorPath(
    val path: Path,
    val fill: Color?,
    val stroke: Color?,
    val strokeWidth: Float,
    val strokeCap: androidx.compose.ui.graphics.StrokeCap,
    val strokeJoin: androidx.compose.ui.graphics.StrokeJoin,
)

private data class MeasuredTracePath(
    val path: Path,
    val stroke: Color,
    val strokeWidth: Float,
    val strokeCap: androidx.compose.ui.graphics.StrokeCap,
    val strokeJoin: androidx.compose.ui.graphics.StrokeJoin,
    val startProgress: Float,
    val endProgress: Float,
)
