package com.npay.animationpoc.ui

import androidx.compose.runtime.Composable
import com.npay.animationpoc.ui.preview.PaymentStatusPreviewScreen

@Composable
fun PaymentAnimationComparisonApp() {
    PaymentStatusPreviewScreen()
}
