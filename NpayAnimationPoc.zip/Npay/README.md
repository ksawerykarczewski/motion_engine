# Npay Animation POC

Local Android proof of concept for previewing native Jetpack Compose status icon animation.

The app focuses on path-controlled status icons, with controls for payment state, motion style, duration, delay, easing, loop mode, path reveal, alpha, scale, replay, and reduced motion.

The workspace is split into two views:

- **Design**: tune and preview motion quickly.
- **Handoff**: review the approved motion spec, validation messages, generated JSON, and production-shaped Compose snippet.

## Requirements

- Android Studio Ladybug or newer
- JDK 17
- Android SDK 35
- Min SDK: 26

## Setup

1. Open this folder in Android Studio.
2. Let Gradle sync the project.
3. Run the `app` configuration on an emulator or Android POS test device.

If Android Studio asks for a Gradle wrapper, either generate one from Android Studio or run `gradle wrapper` from a machine with Gradle installed.

## Structure

```text
app/src/main/java/com/npay/animationpoc/
  MainActivity.kt
  ui/
    PaymentAnimationComparisonApp.kt
    motionspec/
      PaymentMotionSpec.kt
    preview/
      PaymentStatusPreviewScreen.kt
    statusanimation/
      AnimatedStatusIcon.kt
      StatusIconAnimationSpec.kt
    statusicons/
      StatusIconAsset.kt
    theme/
      Theme.kt
      Type.kt

app/src/main/assets/status-icons/
  README.md
  catalog.json
  svg/
    checkmark.svg
    error.svg
    fail.svg
    loading.svg
```

## Implementation Notes

Native Compose animation:

- Uses `Animatable`, native Compose rendering, and explicit animation presets.
- Builds Compose `ImageVector` paths from SVG path data for final vector rendering.
- Uses `PathMeasure.getSegment()` for fluid centerline path reveal where an icon provides trace paths.
- Keeps icon metadata in `StatusIconAsset.kt` and motion defaults in `StatusIconAnimationSpec.kt`.
- Uses `PaymentMotionSpec` as the handoff contract between design tuning and developer output.
- Supports static, trace, fade, pop, pulse, and loading-specific sequential styles with duration, easing, loop/yoyo behavior, alpha, scale, path reveal, transition duration, and transition easing controls.

Developer handoff:

- Tune motion in the Design view.
- Press **Mark** to save the current state as the in-session handoff candidate.
- Review validation, `motion-spec.json`, the Compose usage snippet, and the implementation reference in the Handoff view.
- Treat JSON as the reviewable source of truth and the Compose snippet as the intended integration shape.
- Use the implementation reference to see the exact Compose easing, tween values, and renderer behavior behind named presets such as `Pop`, `Trace`, and `SequentialAppear`.

Replacing or adding an icon:

1. Add or replace the source SVG in `app/src/main/assets/status-icons/svg/`.
2. Update `app/src/main/assets/status-icons/catalog.json` if the file name, label, description, or default color changed.
3. Run `node tools/import-status-icons.mjs` to regenerate `StatusIconAsset.kt`.
4. Add explicit centerline `tracePaths` in `catalog.json` only when a filled SVG needs path reveal.
5. Add or update recommended motion in `StatusIconAnimationPresets`.

## Future Experiment Hooks

- Add timing instrumentation around replay actions.
- Add multiple simultaneous animation instances to test scalability.
- Add low-end POS device profiles and reduced frame-rate scenarios.
- Add visual variants for declined, pending, and refunded payment states.
- Add file export/copy integration for the generated JSON and Kotlin output.
- Add golden previews for approved states.

## Motion Guidance

- Success should feel calm and definitive: a 350-450 ms trace with a small delay is enough.
- Error and failure states should appear quickly, usually 180-240 ms, with fade or restrained pop rather than playful motion.
- Loading exposes two native Compose sequential styles: `SequentialAppear` and `SequentialAlphaPulse`.
- `SequentialAppear` renders one vector layer and moves a single hidden gap through the path list while every other segment stays fully visible.
- Loading sequence order follows SVG path order. Reorder paths in the source SVG when the visual rhythm needs to change.
- Future loading motion should avoid full-icon disappearance, flashy loops, and distracting movement in POS checkout flows.
- Prefer path reveal only when a centerline trace path exists. Do not trace filled SVG outlines; use `StatusIconTracePath` for the intended motion path.
